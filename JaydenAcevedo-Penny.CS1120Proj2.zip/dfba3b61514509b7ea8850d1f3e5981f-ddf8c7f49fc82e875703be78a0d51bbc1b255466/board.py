# Project No.: 2
# Author: Jayden Acevedo-Penny
# Description: Boggle board game

import random
import string

class BoggleBoard:
    def __init__(self, seed):
        random.seed = seed
        self.board = []
        for rows in range(4):
            row = []
            for columns in range(4):
                row.append(random.choice(string.ascii_uppercase))
            self.board.append(row)

    def display_board(self):
        for rows in self.board:
            print("+---+---+---+---+")
            print("| " + " | ".join(rows) + " |")
        print("+---+---+---+---+")

    def find_word(self, word):
        def check_for_word(row, colum, index):
            #returning true if the word is found on the board
            if index == len(word):
                return True
            # returning false if the word is not in the board
            if row < 0 or colum < 0 or row >= 4 or colum >= 4 or self.board[row][colum] != word[index]:
                return False
            #marking a letter as visited
            temp, self.board[row][colum] = self.board[row][colum],
            #checking neighboring letters
            found = (check_for_word(row + 1, colum, index + 1) or check_for_word(row - 1, colum, index + 1)
                     or check_for_word(row, colum + 1, index + 1)
                     or check_for_word(row, colum - 1, index + 1))
            self.board[row][colum] = temp

            return found

        # starts searching for word if the first letter matches
        for i in range(4):
            for j in range(4):
                if self.board[i][j] == word[0]:
                    if check_for_word(i, j, 0):
                            return True
        return False

    def is_palindrome(self, user_word):
        if len(user_word) <= 1:
            return True
        elif user_word[0] == user_word[-1]:
            return self.is_palindrome(user_word[1:-1])
        else:
            return False

